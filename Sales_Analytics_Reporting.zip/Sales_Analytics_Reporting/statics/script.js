const currencyFormatter = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0
});
const numberFormatter = new Intl.NumberFormat("en-US");
const chartInstances = {};
const chartColors = ["#1c745c", "#e2a744", "#df765e", "#5186a4", "#8a9b65"];

function formatCurrency(value) {
    return `₹${currencyFormatter.format(Number(value) || 0)}`;
}

function formatNumber(value) {
    return numberFormatter.format(Number(value) || 0);
}

function renderChart(elementId, configuration) {
    const canvas = document.getElementById(elementId);
    if (chartInstances[elementId]) {
        chartInstances[elementId].destroy();
    }
    chartInstances[elementId] = new Chart(canvas, configuration);
}

function revenueAxis() {
    return {
        ticks: {
            color: "#74817b",
            callback: value => formatCurrency(value)
        },
        grid: { color: "#edf1ee" },
        border: { display: false }
    };
}

function renderRevenueCharts(data) {
    renderChart("monthlySalesChart", {
        type: "line",
        data: {
            labels: data.monthly_sales.map(item => item.month),
            datasets: [{
                label: "Revenue",
                data: data.monthly_sales.map(item => Number(item.revenue) || 0),
                borderColor: "#18765c",
                backgroundColor: "rgba(24, 118, 92, 0.12)",
                pointBackgroundColor: "#ffffff",
                pointBorderColor: "#18765c",
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                fill: true,
                borderWidth: 2.5,
                tension: 0.32
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: "index" },
            plugins: {
                legend: { display: false },
                tooltip: { callbacks: { label: context => formatCurrency(context.raw) } }
            },
            scales: {
                x: { ticks: { color: "#74817b" }, grid: { display: false }, border: { display: false } },
                y: revenueAxis()
            }
        }
    });

    [
        { id: "topProductsChart", rows: data.top_products, label: item => item.product_name },
        { id: "topCustomersChart", rows: data.top_customers, label: item => item.name }
    ].forEach(({ id, rows, label }) => {
        renderChart(id, {
            type: "bar",
            data: {
                labels: rows.map(label),
                datasets: [{
                    data: rows.map(item => Number(item.revenue) || 0),
                    backgroundColor: chartColors,
                    borderRadius: 4,
                    barThickness: 18
                }]
            },
            options: {
                indexAxis: "y",
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: context => formatCurrency(context.raw) } }
                },
                scales: {
                    x: { ...revenueAxis(), beginAtZero: true },
                    y: { grid: { display: false }, ticks: { color: "#59665f" }, border: { display: false } }
                }
            }
        });
    });
}

function renderStatusChart(elementId, rows, labelKey) {
    renderChart(elementId, {
        type: "doughnut",
        data: {
            labels: rows.map(item => item[labelKey]),
            datasets: [{
                data: rows.map(item => Number(item.count) || 0),
                backgroundColor: chartColors,
                borderColor: "#ffffff",
                borderWidth: 3,
                hoverOffset: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "68%",
            plugins: {
                legend: { position: "bottom", labels: { usePointStyle: true, pointStyle: "circle", padding: 18, color: "#59665f" } }
            }
        }
    });
}

function renderRecentOrders(orders) {
    const tableBody = document.getElementById("recentOrders");
    tableBody.replaceChildren();

    if (orders.length === 0) {
        const emptyRow = document.createElement("tr");
        emptyRow.innerHTML = '<td class="table-message" colspan="5">No recent orders found.</td>';
        tableBody.appendChild(emptyRow);
        return;
    }

    orders.forEach(order => {
        const row = document.createElement("tr");
        const values = [order.order_id, order.customer_name, order.order_date];
        values.forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value ?? "--";
            row.appendChild(cell);
        });

        const statusCell = document.createElement("td");
        const badge = document.createElement("span");
        const status = String(order.status ?? "Unknown");
        badge.className = `status-badge status-${status.toLowerCase()}`;
        badge.textContent = status;
        statusCell.appendChild(badge);
        row.appendChild(statusCell);

        const amountCell = document.createElement("td");
        amountCell.className = "amount-cell";
        amountCell.textContent = formatCurrency(order.total_amount);
        row.appendChild(amountCell);
        tableBody.appendChild(row);
    });
}

function renderPerformanceSummary(data) {
    const peakMonth = data.monthly_sales.reduce(
        (best, current) => Number(current.revenue) > Number(best?.revenue ?? -Infinity) ? current : best,
        null
    );
    const leadingProduct = data.top_products[0];
    const leadingCustomer = data.top_customers[0];
    const completed = data.order_status.find(item => item.status === "COMPLETED")?.count ?? 0;
    const completionRate = data.orders ? Math.round((completed / data.orders) * 100) : 0;

    document.getElementById("peakMonth").textContent = peakMonth?.month ?? "No data";
    document.getElementById("peakRevenue").textContent = peakMonth ? formatCurrency(peakMonth.revenue) : "--";
    document.getElementById("leadingProduct").textContent = leadingProduct?.product_name ?? "No data";
    document.getElementById("leadingProductRevenue").textContent = leadingProduct ? formatCurrency(leadingProduct.revenue) : "--";
    document.getElementById("leadingCustomer").textContent = leadingCustomer?.name ?? "No data";
    document.getElementById("leadingCustomerRevenue").textContent = leadingCustomer ? formatCurrency(leadingCustomer.revenue) : "--";
    document.getElementById("completedOrders").textContent = formatNumber(completed);
    document.getElementById("completionRate").textContent = `${completionRate}% of all orders`;
}

async function loadDashboard() {
    const errorMessage = document.getElementById("dashboardError");
    const refreshButton = document.getElementById("refreshButton");
    refreshButton.disabled = true;
    refreshButton.textContent = "Refreshing...";
    errorMessage.hidden = true;

    try {
        const response = await fetch("/api/dashboard", { headers: { Accept: "application/json" } });
        if (!response.ok) {
            throw new Error(`Dashboard request failed (${response.status})`);
        }

        const data = await response.json();
        ["revenue", "orders", "customers", "products"].forEach(key => {
            document.getElementById(key).textContent = key === "revenue"
                ? formatCurrency(data.revenue)
                : formatNumber(data[key]);
        });

        data.monthly_sales = Array.isArray(data.monthly_sales) ? data.monthly_sales : [];
        data.top_products = Array.isArray(data.top_products) ? data.top_products : [];
        data.top_customers = Array.isArray(data.top_customers) ? data.top_customers : [];
        data.order_status = Array.isArray(data.order_status) ? data.order_status : [];
        data.payment_status = Array.isArray(data.payment_status) ? data.payment_status : [];
        data.recent_orders = Array.isArray(data.recent_orders) ? data.recent_orders : [];

        renderRevenueCharts(data);
        renderStatusChart("orderStatusChart", data.order_status, "status");
        renderStatusChart("paymentStatusChart", data.payment_status, "payment_status");
        renderRecentOrders(data.recent_orders);
        renderPerformanceSummary(data);
        document.getElementById("lastUpdated").textContent = new Intl.DateTimeFormat("en-IN", {
            hour: "numeric",
            minute: "2-digit"
        }).format(new Date());
    } catch (error) {
        errorMessage.textContent = `Dashboard data could not be loaded. ${error.message}`;
        errorMessage.hidden = false;
        console.error("Dashboard error:", error);
    } finally {
        refreshButton.disabled = false;
        refreshButton.textContent = "Refresh data";
    }
}

document.getElementById("refreshButton").addEventListener("click", loadDashboard);
loadDashboard();